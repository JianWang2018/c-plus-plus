//
//  main.cpp
//  pro3
//
//  Created by 周怡伽 on 2017/11/9.
//  Copyright © 2017年 周怡伽. All rights reserved.
//
#include<iostream>
#include<vector>
#include<cmath>
#include<fstream>
#include <set>
#include <algorithm>
#include <string>
#define PI 3.1415926
#define N  100000
using namespace std;
// define the five functions that will be used in this project
double f1 (double x){
    
    return exp(x);
    
}
double f1_2d (double x){
    
    return exp(x);
    
}
double f1_4d (double x){
    
    return exp(x);
    
}
double f2 (double x){
    
    return exp(sin(2*x))*cos(2*x);
    
}

double f2_2d (double x){
    
    return cos(2*x)*(4*exp(sin(2*x)*pow(cos(2*x),2)-4*exp(sin(2*x)*sin(2*x))))-4*exp(sin(2*x))*cos(2*x)-8*exp(sin(2*x))*sin(2*x)*cos(2*x);
    
}
double f2_4d (double x){
    
    return -8*sin(2*x)*(8*exp(sin(2*x))*pow(cos(2*x),3)-8*exp(sin(2*x))*cos(2*x)-24*exp(sin(2*x))*sin(2*x)*cos(2*x))-24*cos(2*x)*(4*exp(sin(2*x))*pow(cos(2*x),2)-4*exp(sin(2*x))*sin(2*x))+cos(2*x)*(48*exp(sin(2*x))*pow(sin(2*x),2)+16*exp(sin(2*x))*sin(2*x)+16*exp(sin(2*x))*pow(cos(2*x),4)-64*exp(sin(2*x))*pow(cos(2*x),2)-96*exp(sin(2*x))*sin(2*x)*pow(cos(2*x),2))+16*exp(sin(2*x))*cos(2*x)+64*exp(sin(2*x))*sin(2*x)*cos(2*x);
    
}
double f3 (double x){
    
    return tanh(x);
    
}
double f3_2d (double x){
    
    return -2*sinh(x)/pow(cosh(x),3);
    
}
double f3_4d (double x){
    
    return -2*(sinh(3*x)-11*sinh(x))/pow(cosh(x),5);
    
}
double f4 (double x){
    
    return x*cos(2*PI*x);
    
}
double f4_2d (double x){
    
    return -4*PI*sin(2*PI*x)+PI*x*cos(2*PI*x);
    
}
double f4_4d (double x){
    
    return 16*pow(PI,3)*(2*sin(2*PI*x)+PI*x*cos(2*PI*x));
    
}
double f5 (double x){
    
    return x+1/x;
    
}
double f5_2d (double x){
    
    return 2/(pow(x,3));
    
}
double f5_4d (double x){
    
    return 24/(pow(x,5));
    
}
//newton_closed_trapezoidal rule
vector<double> newton_closed_trapezoidal(double n,double Ie,double a,double b,double(*f)(double x),double (*f_2d)(double x))
{
    double h =fabs(b-a)/n;
    vector<double> res(3);
    vector<double> x(n+1);
    x[0]=a;
    for( int i = 0 ;i<=n;i++){
        x[i]=a+h*i;
    }
    double max_val;
   for(int j=0;j<=n;j++){
    max_val=max(f_2d(x[j]),max_val);
 }
     //cout.precision(10);
    //cout<<max_val<<" ";
    double I=0.0;
   double err1;
    for(int i=0;i<n;i++){
         I=I+h/2.0*(f(x[i])+f(x[i+1]));
         }
       res[1]=Ie-I;
        res[0]=I;
    err1=exp(3);
   //err1=12.99006622;
   // err1=0.7698003589;
   // err1=15.42994643;
   // err1=2000;
    res[2]=err1;
    //res[2]=err1*(-pow((b-a),3)/(12*pow(n,2)));
  //  res[2]=(-pow((b-a),3)/(12*pow(n,2)))*max_val;
    return res;
         }

// newton_closed_simpson rule
vector<double> newton_closed_simpson(double n,double Ie,double a,double b,double(*f)(double x),double (*f_4d)(double x))

{   double err1;
    double h =fabs(b-a)/(2*n);
    vector<double> res(3);
    vector<double> x(2*n+1);
    for( int i = 0 ;i<=n;i++){
        x[i]=a+2*h*i;

    }
//    double max_val =0.0;
//    for(int i=0;i<n;i++){
//        max_val=max(f_4d(x[i]),max_val);
//    }
  // cout.precision(10);
  //  cout<<max_val<<" ";
   // res[2]=-pow((b-a),5)/(2880*pow(n,4))*max_val;
   err1=exp(3);
   // err1= 396.9752921;
   // err1=4.085885503;
    //err1= 4835.929283;
   //err1=2400000;
    res[2]=err1;
    //res[2]=err1*(-pow((b-a),5)/(2880*pow(n,4)));
    double I=0.0;
    for(int i=0;i<n;i++){
        I=I+h*(1/3.0*f(x[i])+4/3.0*f((x[i]+x[i+1])/2)+1/3.0*f(x[i+1]));
    }
    res[1]=Ie-I;
    res[0]=I;
    return res;
}
//newton_open_midpoint rule
vector<double> newton_open_midpoint(double n,double Ie,double a,double b,double(*f)(double x),double (*f_2d)(double x))

{
    double h =fabs(b-a)/(n);
    vector<double> res(3);
    vector<double> x(n+1);
    for( int i = 0 ;i<=n;i++){
        x[i]=a+h*i;
        
    }
    double max_val =0.0;
    
    for(int i=0;i<n;i++){
        max_val=max(f_2d(x[i]),max_val);
    }
    //res[2]=-pow((b-a),3)/(12*pow(n,3))*max_val;
    
    
    double err1, I=0.0;
    for(int i=0;i<n;i++){
        
        I=I+h*f((x[i]+x[i+1])/2);
        
    }
    res[1]=Ie-I;
    res[0]=I;
    err1=exp(3);
  //  err1=12.99006622;
    //err1=0.7698003589;
    //err1=15.42994643;
      //err1=2000;
    res[2]=err1;
   // res[2]=err1*(pow((b-a),3)/(24*pow(n,2)));
    return res;
}
//newton_open_trapezoidal rule
vector<double> newton_open_trapezoidal(double n,double Ie,double a,double b,double(*f)(double x),double (*f_2d)(double x))

{
    double h =fabs(b-a)/(3*n);
    vector<double> res(3);
    vector<double> x(n+1);
    for( int i = 0 ;i<=n;i++){
        x[i]=a+3*h*i;
        
    }
//    double max_val =0.0;
//
//    for(int i=0;i<n;i++){
//        max_val=max(f_2d(x[i]),max_val);
//    }
   // res[2]=-pow((b-a),3)/(12*pow(n,3))*max_val;
    double err1;
    err1=exp(3);
   // err1=12.99006622;
    //err1=0.7698003589;
    //err1=15.42994643;
    //err1=2000;
    res[2]=err1;
    //res[2]=err1*(pow((b-a),3)/(36*pow(n,2)));
    double I=0.0;
    for(int i=0;i<n;i++){
        I=I+1.5*h*(f(x[i]+h)+f(x[i+1]-h));
    }
    res[1]=Ie-I;
    res[0]=I;
    return res;
}
//gauss_legendre
vector<double> gauss_legendre(int n,double Ie,double a,double b,double(*f)(double x),double (*f_4d)(double x))

{
    double u0[n+1],u1[n+1];
    double z0=-1/pow(3, 0.5);
    double z1=1/pow(3, 0.5);
    double h =fabs(b-a)/n;
    vector<double> res(3);
    vector<double> x(n+1);
    for( int i = 0 ;i<=n;i++){
        x[i]=a+h*i;
        
    }
    double max_val =0.0;
    
    for(int i=0;i<n;i++){
        max_val=max(f_4d(x[i]),max_val);
    }
    //res[2]=-pow((b-a),3)/(12*pow(n,3))*max_val;
    
    
    double I=0.0;
    for (int i=0; i<=n-1; i++) {
        u0[i]=(z0*(x[i+1]-x[i])+(x[i+1]+x[i]))/2;
        u1[i]=(z1*(x[i+1]-x[i])+(x[i+1]+x[i]))/2;
        I+=((x[i+1]-x[i])/2.0)*(f(u0[i])+f(u1[i]));
    }
    res[1]=Ie-I;
    res[0]=I;
    double err1;
    err1=exp(3);
    //err1=396.9752921;
    // err1=4.085885503;
     // err1= 4835.929283;
       //err1=2400000;
    res[2]=err1*(pow((b-a),5)/(4320*pow(n,4)));
    return res;
}


//newton_closed_trapezoidal_reuse
double newton_closed_trapezoidal_reuse(double n,double Ie,double a,double b,double(*f)(double x),double (*f_2d)(double x))
{
    double h =fabs(b-a)*2/n;
    double h_refine= h/2.0;
    double sum = 0.0;
    double res;
    for ( int i = 1 ; i <=n/2; i++){
        sum+=f(a+h_refine+h_refine*(i-1)*2);
    }
    res = 0.5*( newton_closed_trapezoidal(n/2,Ie,a,b,f,f_2d)[0]+h*sum);
    return res;
}

//newton_closed_simpson_reuse
double newton_closed_simpson_a(int n,double a,double b,double(*f)(double x)){
    double h= fabs(b-a)/n;
    return h/6.0*(f(a)+f(b));
}

double newton_closed_simpson_b(int n,double a,double b,double(*f)(double x)){
    double h= fabs(b-a)/n;
    double res= 0.0;
    if(n<2) return 0.0;
    
    for(int i =0; i<n-1 ; i++){
        res+=f(a+(i+1)*h);
    }
    return h/6.0*(2*res);
}

double newton_closed_simpson_c(int n,double a,double b,double(*f)(double x)){
    double h= fabs(b-a)/n;
    double h_refine=h/2.0;
    double res= 0.0;
    
    for(int i =0; i<n ; i++){
        res+=f(a+h_refine+i*h);
    }
    return h/6.0*(4*res);
}

double newton_closed_simpson_reuse(double n,double Ie,double a,double b,double(*f)(double x),double (*f_4d)(double x)){
    double h =fabs(b-a)/(n);
    vector<double> res(3);
    double I =0.0;
    if (n==1) return h/6*(f(a)+4*f((a+b)/2.0)+f(b));
    
    I = 0.5*newton_closed_simpson_a(n/2,a,b,f)+0.5*newton_closed_simpson_b(n/2,a,b,f)+0.25*newton_closed_simpson_c(n/2,a,b,f)+newton_closed_simpson_c(n,a,b,f);
    res[1]=Ie-I;
    res[0]=I;
    return I;
}

//newton_open_midpoint_reuse
double newton_open_midpoint_reuse(double n,double Ie,double a,double b,double(*f)(double x),double (*f_2d)(double x))

{
    int n_last=n/3;
    int n_last_mesh=n_last*2;
    int n_mesh= n*2;
    
    set<double> points;
    set<double> new_points;
    
    for(int i =1;i<n_last_mesh;i++){
        points.insert(1.0*i/n_last_mesh);
    }
    
    for(int i = 1; i<n;i++){
        points.insert(1.0*i/n);
    }

    for (int i =1 ;i<n_mesh;i++){
        if(points.find(1.0*i/n_mesh)==points.end()) {
            new_points.insert(1.0*i/n_mesh);
        }
    }

    double sum = 0.0;
    double res;
    for ( auto item :  new_points){
        sum+=f(a+item*fabs(b-a));
    }
 
    res = 1/3.0*newton_open_midpoint(n_last,Ie,a,b,f,f_2d)[0]+double(fabs(b-a))/n*sum;
    return res;
}

//newton_open_trapezoidal_reuse
double newton_open_trapezoidal_reuse(double n,double Ie,double a,double b,double(*f)(double x),double (*f_2d)(double x))
{
    int n_last=n/2;
    int n_last_mesh=n_last*3;
    int n_mesh= n*3;
    
    set<double> points;
    set<double> new_points;
    
    for(int i =1;i<n_last_mesh;i++){
        points.insert(1.0*i/n_last_mesh);
    }
    
    for(int i = 1; i<n;i++){
        points.insert(1.0*i/n);
    }
    
    for (int i =1 ;i<n_mesh;i++){
        if(points.find(1.0*i/n_mesh)==points.end()) {
            new_points.insert(1.0*i/n_mesh);
        }
    }    
    double sum = 0.0;
    double res;
    for ( auto item :  new_points){
        sum+=f(a+item*fabs(b-a));
    }
    
    res = 1/2.0*newton_open_trapezoidal(n_last,Ie,a,b,f,f_2d)[0]+1/2.0*double(fabs(b-a))/n*sum;
    
    return res;
}
//main
int main()
{
    vector<double> result(3);
    //double len_inteval=3.0;
    //double len_inteval=PI/3;
   // double len_inteval=3.5;
     double len_inteval=2.4;
  //double Ie=19.085536923188;
    //double Ie=0.688721337618082;
    //double Ie= -0.891221916874837;
    //double Ie=-0.050660593549522;
   double Ie=6.3388758248682;

//----------------------3.1----------------------------------
 // -------------------------newton closed trapezoidal rule reuse--------------------
        int n=1;
    vector<double> res_co;
    double error=10;
    double err1;
    //err1=exp(3);
    //err1=12.99006622;
    //err1=0.7698003589;
   // err1=15.42994643;
   // err1=2000;
    
    //err1=exp(3);
    // err1= 396.9752921;
    // err1=4.085885503;
    //err1= 4835.929283;
    err1=2400000;
   
        while(error>=(pow(10,-5))){
            //res_co=newton_closed_trapezoidal(n,Ie,0.1,2.5,f5,f1_2d);
            // error=fabs((err1*(-pow(len_inteval,3)/(12*pow(n,2)))));
            res_co=newton_closed_simpson(n,Ie,0.1,2.5,f5,f1_2d);
              error=fabs((err1*(-pow(len_inteval,5)/(2880*pow(n,4)))));
            // res_co=newton_open_midpoint(n,Ie,0.1,2.5,f5,f1_2d);
          // error=fabs((err1*(-pow(len_inteval,3)/(24*pow(n,2)))));
           // res_co=newton_open_trapezoidal(n,Ie,0.1,2.5,f5,f1_2d);
            //error=fabs((err1*(pow(len_inteval,3)/(36*pow(n,2)))));
        // res_co=gauss_legendre(n,Ie,0.1,2.5,f5,f1_2d);
          //  error=fabs((err1*(pow(len_inteval,5)/(4320*pow(n,4)))));
            n+=1;
        }
    cout.precision(10);
    cout<<n<<" & "<<len_inteval/n<<" & "<<res_co[0]<<" & "<<Ie-res_co[0]<<"\\\\ \\\hline "<<endl;
    }


//int n;
//ofstream fout;
//fout.open("closed_trap_res5.txt");
//fout.open("closed_simpson_reuse.txt");
//fout.open("open_midpoint5.txt");
//fout.open("open_trap5.txt");
//fout.open("gauss_legendre5.txt");
//fout.precision(10);
//double res_refine;
//for (int i = 0 ; i <n.size();i++){
// result=newton_closed_trapezoidal(n,Ie,0.1,2.5,f5,f5_2d);
//result=newton_closed_simpson_reuse(n,Ie,0.0,3.0,f1,f1_4d);
//result=newton_open_midpoint(n,Ie,0.1,2.5,f5,f5_2d);
//result=newton_open_trapezoidal(n,Ie,0.1,2.5,f5,f5_2d);
//result=gauss_legendre(n,Ie,0.1,2.5,f5,f5_4d);
//fout<<n[i]<<" & "<<len_inteval/n[i]<<" & "<<result[0]<<" & "<<result[1]<<" & "<<result[2]<<"\\\\ "<<"\\hline "<<endl;}
//  fout.close();

//----------now calculate the h which make various error tol -------------
//    double res_refine1;
//    double tol=0.0001;
//    double error1=100;
//    int iter_num=2;
//    cout<<Ie;
//    while (error1>tol){
//        res_refine1=newton_closed_trapezoidal(iter_num,Ie,0.0,3.0,f1,f1_2d)[0];
//        error1= fabs(res_refine1-Ie);
//        iter_num*=2;
//    }
//    cout<<len_inteval/iter_num<<" "<<iter_num;
  
    //double tol=0.00001;
    //double tol=0.001;
  //  double tol=0.0001;
   // double tol=0.00001;
  // double error=100;
  //  double iter_num=2;
   // result=newton_closed_simpson(iter_num,Ie,0.0,PI/3,f2,f2_2d);
   // while (error>tol){
     //  result=newton_closed_trapezoidal(iter_num,Ie,-2.0,1.0,f3,f3_2d);
      //  result=newton_open_midpoint(iter_num,Ie,0.0,PI/3,f2,f2_2d);
      // result=newton_open_trapezoidal(iter_num,Ie,0.0,PI/3,f2,f2_2d);
       //result=gauss_legendre(iter_num,Ie,0.0,PI/3,f2,f2_2d);
    //  error= fabs(Ie-result[0]);
     //   iter_num+=1;
  // }
 //   cout.precision(10);
     //   cout<<"f2"<<" & "<<tol<<" & "<<len_inteval/iter_num<<" & "<<iter_num<<" & "<<result[0]<<" & "<<result[1]<<"\\\\ "<<"\\hline "<<endl;
//-------------------------3.2---------------------reuse------------------------------
    
//-------------------------newton closed trapezoidal rule reuse--------------------
//    int n=1;
//    ofstream fout;
//    fout.open("closed_trap_res2.txt");
//    fout.precision(10);
//    double res_refine;
//    vector<double> res_co;
//     vector<double> res_co1;
//    double error=1000;
//    while(error>0.00001){
//        res_refine=newton_closed_trapezoidal_reuse(n,Ie,0.0,PI/3,f2,f1_2d);
//        res_co=newton_closed_trapezoidal(n/2,Ie,0.0,PI/3,f2,f1_2d);
//        res_co1=newton_closed_trapezoidal(n,Ie,0.0,PI/3,f2,f1_2d);
//        error=fabs((res_refine-res_co[0])/3.0);
//        fout.precision(10);
//        fout<<n<<" & "<<len_inteval/n<<" & "<<res_refine<<" & "<<Ie-res_refine<<" & "<<res_co1[2]<<" & "<<(res_refine-res_co[0])/3.0<<"\\\\ \\\hline "<<endl;
//        n*=2;
//    }
//    fout.close();
//}

    //--------------------------- newton closed simpson rule--------------------
//     int n;
//       n=1;
//      ofstream fout;
//        fout.open("closed_simpson_res2.txt");
//fout.precision(10);
//double res_refine;
//vector<double> res_co;
//    vector<double> res_co1;
// double error=1000;
//while(error>0.00001){
//    res_refine=newton_closed_simpson_reuse(n,Ie,0.0,PI/3,f2,f1_2d);
//    res_co=newton_closed_simpson(n/2,Ie,0.0,PI/3,f2,f1_2d);
//    res_co1=newton_closed_simpson(n,Ie,0.0,PI/3,f2,f1_2d);
//    error=fabs((res_refine-res_co[0])/15.0);
//    fout.precision(10);
//fout<<n<<" & "<<len_inteval/n<<" & "<<res_refine<<" & "<<Ie-res_refine<<" & "<<res_co1[2]<<" & "<<(res_refine-res_co[0])/15.0<<"\\\\ \\\hline "<<endl;
//n*=2;
//
//}
//    fout.close();
//}
   //--------------------------newton open midpoint rule------------------------------
//   int n;
//    n=3;
//    ofstream fout;
//   fout.open("newton_open_midpoint_res2.txt");
//    fout.precision(10);
//  double res_refine;
//vector<double> res_co;
//     vector<double> res_co1;
//double error=1000;
//while(error>0.00001){
//    res_refine=newton_open_midpoint_reuse(n,Ie,0.0,PI/3,f2,f1_2d);
//    res_co=newton_open_midpoint(n/3,Ie,0.0,PI/3,f2,f1_2d);
//    res_co1=newton_open_midpoint(n,Ie,0.0,PI/3,f2,f1_2d);
//error=fabs((res_refine-res_co[0])/8.0);
//fout.precision(10);
//    fout<<n<<" & "<<len_inteval/n<<" & "<<res_refine<<" & "<<Ie-res_refine<<" & "<<res_co1[2]<<" & "<<(res_refine-res_co[0])/8.0<<"\\\\ \\\hline "<<endl;
//n*=3;
//    cout.precision(10);
//    cout<<res_co[0];
//}
//
// fout.close();
//}
//--------------------------newton open trap rule------------------------------
//int n;
//n=1;
//ofstream fout;
//fout.open("open_trap_res2.txt");
//fout.precision(10);
//double res_refine;
//vector<double> res_co;
//    vector<double> res_co1;
//double error=1000;
//while(error>0.00001){
//res_refine=newton_open_trapezoidal_reuse(n,Ie,0.0,PI/3,f2,f1_2d);
//res_co=newton_open_trapezoidal(n/2,Ie,0.0,PI/3,f2,f1_2d);
//res_co1=newton_open_trapezoidal(n,Ie,0.0,PI/3,f2,f1_2d);
//error=fabs((res_refine-res_co[0])/3.0);
//fout.precision(10);
//fout<<n<<" & "<<len_inteval/n<<" & "<<res_refine<<" & "<<Ie-res_refine<<" & "<<res_co1[2]<<" & "<<(res_refine-res_co[0])/3.0<<"\\\\ \\\hline "<<endl;
//n*=2;
//}
// fout.close();
//}

